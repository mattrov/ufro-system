<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="card col-sm-2" style="height: 20rem;">
	<div class="card-body">
		<h3>Record Type</h3>
		<ul class="nav flex-column" style="font-size: 18px;">
  			<li class="nav-item">
  			  <a class="nav-link" href="viewrecsemployee.php">Employee</a>
  			</li>
  			<li class="nav-item">
  			  <a class="nav-link" href="viewrecsstudent.php">Student</a>
  			</li>
		</ul>
	</div>
</div>
</body>
</html>